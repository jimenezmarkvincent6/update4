<?php
include 'connection.php';

header('Content-Type: application/json'); // Ensure JSON output

if (!isset($_GET['student_id']) || !isset($_GET['authorized_id'])) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit;
}

$student_id = $_GET['student_id'];
$authorized_id = $_GET['authorized_id'];

$child_sql = "SELECT * FROM child_acc WHERE student_id = ? AND authorized_id = ?";
$stmt = $conn->prepare($child_sql);

if ($stmt === false) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
    exit;
}

$stmt->bind_param("ss", $student_id, $authorized_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $child_info = $result->fetch_assoc();
    echo json_encode([
        'success' => true,
        'child_info' => [
            'name' => $child_info['child_name'],
            'teacher' => $child_info['child_teacher'],
            'age' => $child_info['child_age'],
            'grade' => $child_info['child_grade'],
            'section' => $child_info['child_section'],
            'address' => $child_info['child_address']
        ],
        'authorized_info' => [
            'authorized_person_id' => $child_info['authorized_id'],
            'authorized_name' => $child_info['authorized_name']
        ]
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'No records found']);
}

$stmt->close();
?>
