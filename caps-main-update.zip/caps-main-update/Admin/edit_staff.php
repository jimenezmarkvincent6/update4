<?php
// edit_staff.php
header('Content-Type: application/json');
session_start(); // Start the session
include 'connection.php';

try {
    // Connect to the database using PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]);
    exit;
}

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect data from the POST request
    $staffId = $_POST['user_id'] ?? null; // Match the hidden input field name
    $fullname = $_POST['fullname'] ?? null;
    $contactNumber = $_POST['contact_number'] ?? null;
    $email = $_POST['email'] ?? null;
    $address = $_POST['address'] ?? null;
    $role = $_POST['role'] ?? null;
    $password = $_POST['password'] ?? null;

    // Validate inputs
    if (!$staffId || !$fullname || !$contactNumber || !$email || !$address || !$role) {
        echo json_encode(['success' => false, 'message' => 'All fields except password are required.']);
        exit;
    }

    try {
        // Build the SQL query
        $sql = "UPDATE admin_staff 
                SET fullname = :fullname, 
                    contact_number = :contact_number, 
                    email = :email, 
                    address = :address,
                    role = :role";
        if (!empty($password)) {
            $sql .= ", password = :password";
        }
        $sql .= " WHERE id = :id";

        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':fullname', $fullname);
        $stmt->bindParam(':contact_number', $contactNumber);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':role', $role);
        $stmt->bindParam(':id', $staffId);

        if (!empty($password)) {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt->bindParam(':password', $hashedPassword);
        }

        $stmt->execute();

        echo json_encode(['success' => true, 'message' => 'Staff information updated successfully.']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to update staff information: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}
?>
