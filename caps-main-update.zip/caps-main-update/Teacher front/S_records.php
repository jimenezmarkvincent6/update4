

<!DOCTYPE html>
<html>
<head>
    <title>Student Records</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet" />
    <link href="css/s_record.css" rel="stylesheet" />

</head>
<body>
    <div class="sidebar">
    <img src="logo/logo.png" alt="Logo">
        <a href="qr_scanner.php"><i class="fa fa-qrcode"></i>Qr Code Scan</a>
        <a href="S_records.php"><i class="fas fa-user-graduate"></i>Student Records</a>
        <a href="P_records.php"><i class="fas fa-users"></i>Parent Records</a>
        <a href="U_records.php"> <i class="fas fa-clipboard-list"></i>Pick-Up Records</a>
        <div class="bottom-links">
            <a href="#">
                <i class="fas fa-cog"></i> Settings
            </a>
            <a href="#">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>
    <div class="main-content">
        <div class="header">
            <div class="user-info">
                <div class="notification">
                    <i class="fas fa-bell"></i>
                </div>
                <div class="vertical-rule"></div>
                <div class="profile">
                <img alt="User profile picture" height="40" src="https://oaidalleapiprodscus.blob.core.windows.net/private/org-Hh5RPsKhtBPsWCFSiEKnUJ6x/user-8qgiVpCV0U0b7zDjfFInHgjl/img-UaqtED2tWdF8Jj5BdVptvrvZ.png?st=2024-09-08T03%3A49%3A50Z&amp;se=2024-09-08T05%3A49%3A50Z&amp;sp=r&amp;sv=2024-08-04&amp;sr=b&amp;rscd=inline&amp;rsct=image/png&amp;skoid=d505667d-d6c1-4a0a-bac7-5c84a87759f8&amp;sktid=a48cca56-e6da-484e-a814-9c849652bcb3&amp;skt=2024-09-07T23%3A47%3A39Z&amp;ske=2024-09-08T23%3A47%3A39Z&amp;sks=b&amp;skv=2024-08-04&amp;sig=18zzyGV2lWaM/BQ7/LoacKemQW7r9eD1vJOq3I7Ssss%3D" width="40"/>
                <span><?php echo isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : 'Guest'; ?></span><br>
                <span><?php echo isset($_SESSION['user_role']) ? htmlspecialchars($_SESSION['user_role']) : 'Role not defined'; ?></span>
                </div>
            </div>
        </div>
        <hr/>
        <?php
// Include database connection
include 'connection.php';

// Fetch teachers from admin_staff table where the role is "teacher"
$teachers_sql = "SELECT id, fullname FROM admin_staff WHERE role = 'teacher'";
$teachers_result = $conn->query($teachers_sql);

// Fetch parent names from parent_acc table
$parents_sql = "SELECT id, fullname FROM parent_acc";
$parents_result = $conn->query($parents_sql);

// Fetch authorized persons from authorized_persons table
$authorized_persons_sql = "SELECT id, fullname FROM authorized_persons";
$authorized_persons_result = $conn->query($authorized_persons_sql);

// Check for database connection errors
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . htmlspecialchars($conn->connect_error)]));
}
?>
        <div class="table-container">
            <div class="search-bar-container">
                        
                <div class="search-bar">
                <input type="text" id="search" placeholder="Search..." onkeyup="performSearch(event)">
                </div>
            </div>
            <?php
include 'connection.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Pagination variables
$itemsPerPage = 10; // Items per page
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page from the URL
$offset = ($currentPage - 1) * $itemsPerPage; // Offset for SQL query

// Query to select records from the admin_staff table with LIMIT for pagination
$sql = "SELECT id, child_name, student_id, child_grade, child_section, child_address FROM child_acc LIMIT $offset, $itemsPerPage";
$result = $conn->query($sql);

// Count total records for pagination
$totalSql = "SELECT COUNT(*) as total FROM parent_acc";
$totalResult = $conn->query($totalSql);
$totalRow = $totalResult->fetch_assoc();
$totalItems = $totalRow['total'];
$totalPages = ceil($totalItems / $itemsPerPage); // Calculate total pages

// Start the HTML table
echo '<table>
        <thead>
            <tr>
                <th>Student ID</th>
                <th>Name</th>
                <th>Grade</th>
                <th>Section</th>
                <th>Address</th>
                <th style="text-align: center;" >Action</th>
            </tr>
        </thead>
        <tbody>';

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<tr>
                <td>' . htmlspecialchars($row['student_id']) . '</td>
                <td>' . htmlspecialchars($row['child_name']) . '</td>
                <td>' . htmlspecialchars($row['child_grade']) . '</td>
                <td>' . htmlspecialchars($row['child_address']) . '</td>
                <td>' . htmlspecialchars($row['child_section']) . '</td>
                

                <td style="text-align: center;">
                <button class="view-btn" title="View" onclick="openViewModal(' . htmlspecialchars($row['id']) . ')">
                    <i class="fas fa-eye"></i> 
                </button>
                </td>';
        
                echo '</td></tr>';
            }
} else {
    echo '<tr><td colspan="7">No records found</td></tr>';
}

echo '  </tbody>
      </table>';




// Close the database connection
$conn->close();
?>
        <hr/>
        <div class="pagination" id="pagination"></div>
        </div>
    </div>
    <script>
    const totalItems = <?php echo $totalItems; ?>; 
const itemsPerPage = <?php echo $itemsPerPage; ?>; 
let currentPage = <?php echo $currentPage; ?>; 

function renderPagination() {
    const pagination = document.getElementById('pagination');
    pagination.innerHTML = ''; // Clear previous pagination

    const totalPages = Math.ceil(totalItems / itemsPerPage);

    // Previous button
    const prevLink = document.createElement('a');
    prevLink.innerHTML = '«';
    prevLink.className = currentPage === 1 ? 'disabled' : '';
    prevLink.onclick = function() {
        if (currentPage > 1) {
            currentPage--;
            updatePage();
        }
    };
    pagination.appendChild(prevLink);

    // Page numbers
    for (let i = 1; i <= totalPages; i++) {
        const pageNumber = document.createElement('div');
        pageNumber.innerHTML = i;
        pageNumber.className = `page-number ${i === currentPage ? 'active' : ''}`;
        pageNumber.onclick = function() {
            currentPage = i;
            updatePage();
        };
        pagination.appendChild(pageNumber);
    }

    // Next button
    const nextLink = document.createElement('a');
    nextLink.innerHTML = '»';
    nextLink.className = currentPage === totalPages ? 'disabled' : '';
    nextLink.onclick = function() {
        if (currentPage < totalPages) {
            currentPage++;
            updatePage();
        }
    };
    pagination.appendChild(nextLink);
}

function updatePage() {
    window.location.href = '?page=' + currentPage; // Redirect to the correct page
}

// Initial rendering
renderPagination();
</script>
    <script src="script/script.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

    <!-- Loading Overlay (for showing when the page is reloading or submitting) -->
<div class="loading-overlay" id="loading-overlay">
    <div class="loader"></div>
</div>

<style>
    /* Overlay for loading screen */
.loading-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: none; /* Hidden by default */
    justify-content: center;
    align-items: center;
    z-index: 1000;
}

/* Loader animation (a simple spinner) */
.loader {
    border: 5px solid #f3f3f3; /* Light background */
    border-top: 5px solid blue; 
    border-radius: 50%;
    width: 50px;
    height: 50px;
    animation: spin 1s linear infinite;
}

/* Keyframes for spinning loader */
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

    .view-btn {
        border: none;
        padding: 8px 15px;
        border-radius: 5px;
        cursor: pointer;
    }
    .view-btn:hover {
        transform: scale(1.05); /* Slight zoom effect */
    }
    .view-btn i {
        font-size: 16px; /* Adjust icon size */
    }
</style>
<script>

<div id="view-modal" class="modal">
    <div class="modal-content">
        <button class="close" onclick="closeViewModal()">&times;</button>
        <h2>Parent and Authorized Persons Info</h2>
        <div id="modal-body">
            <!-- Content dynamically filled via JavaScript -->
        </div>
    </div>
</div>

function openViewModal(childId) {
    console.log('Fetching parent info for Child ID:', childId);

    fetch(`get_parent_info.php?child_id=${childId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const modalBody = document.getElementById('modal-body');

                // Parent Info Section
                const parentImage = data.parent.parent_image || '/placeholder.svg'; // Default image
                const parentSection = `
                    <div style="display: flex; align-items: center; margin-bottom: 15px;">
                        <img src="${parentImage}" 
                            alt="Parent Image" 
                            style="width: 60px; height: 60px; border-radius: 50%; object-fit: cover; margin-right: 15px; border: 2px solid #ddd;">
                        <div>
                            <p><strong>Parent Name:</strong> ${data.parent.fullname}</p>
                            <p><strong>Address:</strong> ${data.parent.address}</p>
                        </div>
                    </div>
                `;

                // Authorized Persons Section
                const authorizedPersonsSection = `
                    <p><strong>Authorized Persons:</strong></p>
                    <ul>
                        ${data.authorizedPersons.map(person => `
                            <li style="display: flex; align-items: center; margin-bottom: 10px;">
                                <img src="${person.authorized_image || '/placeholder.svg'}" 
                                    alt="Authorized Person Image" 
                                    style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover; margin-right: 10px; border: 1px solid #ddd;">
                                <span>${person.fullname}</span>
                            </li>
                        `).join('')}
                    </ul>
                `;

                // Combine sections and render
                modalBody.innerHTML = parentSection + authorizedPersonsSection;

                // Show the modal
                document.getElementById('view-modal').style.display = 'block';
            } else {
                alert(data.message || 'Failed to load data.');
            }
        })
        .catch(error => console.error('Error fetching parent info:', error));
}
function closeViewModal() {
    document.getElementById('view-modal').style.display = 'none';
}
</script>

</body>
</html>
