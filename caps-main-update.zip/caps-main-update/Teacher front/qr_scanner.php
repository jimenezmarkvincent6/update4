


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code Scanner</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jsqr/dist/jsQR.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div class="container mt-4">
        <h2 class="text-center">QR Code Scanner</h2>
        <div id="reader" style="width: 100%; height: 500px; position: relative; background: #f3f3f3; text-align: center;">
            <video id="videoElement" style="width: 100%; height: 100%; object-fit: cover;"></video>
        </div>

        <!-- Modal to display child and authorized details -->
        <div class="modal fade" id="infoModal" tabindex="-1" role="dialog" aria-labelledby="infoModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="infoModalLabel">Child and Authorized Person Info</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h5>Child Information:</h5>
                        <p><strong>Name:</strong> <span id="childName"></span></p>
                        <p><strong>Teacher:</strong> <span id="teacherName"></span></p>
                        <p><strong>Age:</strong> <span id="childAge"></span></p>
                        <p><strong>Grade:</strong> <span id="childGrade"></span></p>
                        <p><strong>Section:</strong> <span id="childSection"></span></p>
                        <p><strong>Address:</strong> <span id="childAddress"></span></p>
                        <hr>
                        <h5>Authorized Person Information:</h5>
                        <p><strong>Authorized Person ID:</strong> <span id="authorizedID"></span></p>
                        <p><strong>Authorized Person Name:</strong> <span id="authorizedName"></span></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" onclick="timeIn()">Time In</button>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script>
        let videoElement = document.getElementById('videoElement');
        const canvas = document.createElement("canvas");
        const context = canvas.getContext("2d", { willReadFrequently: true });

        // Start the QR scanner
        function startScanner() {
            navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } })
                .then(function(stream) {
                    videoElement.srcObject = stream;  
                    videoElement.setAttribute("playsinline", true);
                    videoElement.play();
                    requestAnimationFrame(scanQRCode);
                })
                .catch(function(error) {
                    alert("Error accessing camera: " + error);
                });
        }

        // Scan QR code continuously
        function scanQRCode() {
            if (videoElement && videoElement.readyState === videoElement.HAVE_ENOUGH_DATA) {
                canvas.height = videoElement.videoHeight;
                canvas.width = videoElement.videoWidth;
                context.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
                const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
                const code = jsQR(imageData.data, canvas.width, canvas.height, { inversionAttempts: "dontInvert" });

                if (code) {
                    handleQRCode(code.data);
                } else {
                    requestAnimationFrame(scanQRCode); 
                }
            } else {
                requestAnimationFrame(scanQRCode); 
            }
        }

        function handleQRCode(qrCodeMessage) {
            console.log("Scanned QR Code: ", qrCodeMessage);
            try {
                const url = new URL(qrCodeMessage);
                const params = new URLSearchParams(url.search);
                const student_id = params.get("student_id");
                const authorized_id = params.get("authorized_id");

                if (student_id && authorized_id) {
                    // Fetch child info from the server using the IDs
                    fetchChildInfo(student_id, authorized_id);
                } else {
                    alert("Invalid QR Code.");
                }
            } catch (error) {
                console.error("Error processing QR Code: ", error);
                alert("Invalid QR Code.");
            }
        }

        function fetchChildInfo(student_id, authorized_id) {
    // Fetch the data from the server based on the scanned QR code
    $.get("fetch_data.php", { student_id: student_id, authorized_id: authorized_id }, function(data) {
        if (data.success) {
            // Populate the modal with fetched data
            const child_info = data.child_info;
            const authorized_info = data.authorized_info;

            document.getElementById("childName").innerText = child_info.name;
            document.getElementById("teacherName").innerText = child_info.teacher;
            document.getElementById("childAge").innerText = child_info.age;
            document.getElementById("childGrade").innerText = child_info.grade;
            document.getElementById("childSection").innerText = child_info.section;
            document.getElementById("childAddress").innerText = child_info.address;

            document.getElementById("authorizedID").innerText = authorized_info.id;
            document.getElementById("authorizedName").innerText = authorized_info.fullname;

            // Show the modal
            $('#infoModal').modal('show');
        } else {
            alert(data.message || "Failed to fetch child information.");
        }
    }).fail(function() {
        alert("Error in fetching data from the server.");
    });
}

        function timeIn() {
            // Get the current date and time for the time-in record
            const timestamp = new Date().toISOString();

            // Get the student_id and authorized_id from the URL
            const urlParams = new URLSearchParams(window.location.search);
            const student_id = urlParams.get('student_id');
            const authorized_id = urlParams.get('authorized_id');

            if (student_id && authorized_id) {
                // Redirect to the attendance page with the parameters
                window.location.href = `http://localhost/capstone-main/attendance.php?student_id=${student_id}&authorized_id=${authorized_id}&time_in=${timestamp}`;

            } else {
                alert("Invalid data. Could not process time in.");
            }
        }

        startScanner();
    </script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
